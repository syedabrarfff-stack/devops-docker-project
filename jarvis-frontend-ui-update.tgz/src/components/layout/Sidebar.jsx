import React from 'react'
import { motion } from 'framer-motion'
import {
  LayoutDashboard, MessageSquare, CheckSquare, Users,
  Newspaper, Zap, Activity, UserCircle, Target,
  Mail, ListTodo, Bell, Calendar, Clock, RefreshCw, Brain, Shield, Layers, Server, Contact2,
} from 'lucide-react'
import useJarvisStore from '../../store/useJarvisStore'

const NAV = [
  { id: 'dashboard',      label: 'Dashboard',       icon: LayoutDashboard },
  { id: 'chat',           label: 'JARVIS Chat',      icon: MessageSquare },
  { id: 'briefing',       label: 'Briefing',         icon: Newspaper },
  { id: 'approvals',      label: 'Approvals',        icon: CheckSquare },
  { id: 'agents',         label: 'Agents',           icon: Users },
  { id: 'crm',            label: 'CRM',              icon: UserCircle },
  { id: 'leads',          label: 'Leads',            icon: Target },
  { id: 'outreach',       label: 'Outreach',         icon: Mail },
  { id: 'tasks',          label: 'Task Queue',       icon: ListTodo },
  { id: 'notifications',  label: 'Notifications',    icon: Bell },
  { id: 'scheduler',      label: 'Scheduler',        icon: Clock },
  { id: 'calendar',       label: 'Calendar',         icon: Calendar },
  { id: 'sync',           label: 'Sync',             icon: RefreshCw },
  { id: 'intelligence',   label: 'Intelligence',     icon: Brain },
  { id: 'governance',    label: 'Governance',       icon: Shield },
  { id: 'catalog',      label: 'Services',         icon: Layers },
  { id: 'ai_ops',      label: 'AI Operations',    icon: Server },
  { id: 'team',        label: 'Team Registry',    icon: Contact2 },
]

export default function Sidebar() {
  const { activeView, setActiveView, wsConnected, pendingApprovals } = useJarvisStore()

  return (
    <aside className="w-20 md:w-64 h-screen flex flex-col bg-[#08080d]/95 backdrop-blur-xl border-r border-white/[0.07] rounded-none">
      {/* Logo */}
      <div className="px-3 md:px-6 py-6 border-b border-white/[0.06]">
        <div className="flex items-center justify-center gap-3 md:justify-start">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-jarvis-blue/30 to-jarvis-purple/30
                          border border-jarvis-blue/30 flex items-center justify-center glow-blue">
            <Zap size={18} className="text-jarvis-blue" />
          </div>
          <div className="hidden min-w-0 md:block">
            <p className="font-bold text-white text-sm tracking-wider">JARVIS</p>
            <p className="text-xs text-white/40">Aliyar Solutions</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2 md:px-3 py-4 space-y-1 overflow-y-auto no-scrollbar">
        {NAV.map(({ id, label, icon: Icon }) => {
          const active = activeView === id
          const badge = id === 'approvals' && pendingApprovals > 0 ? pendingApprovals : null
          return (
            <motion.button
              key={id}
              whileTap={{ scale: 0.97 }}
              onClick={() => setActiveView(id)}
              title={label}
              className={`w-full flex items-center justify-center md:justify-start gap-3 px-3 py-2.5 rounded-lg text-sm
                         transition-all duration-200 group relative
                         ${active
                           ? 'bg-jarvis-blue/15 border border-jarvis-blue/25 text-jarvis-blue'
                           : 'text-white/50 hover:bg-white/[0.05] hover:text-white/80'}`}
            >
              <Icon size={16} className={active ? 'text-jarvis-blue' : 'text-white/40 group-hover:text-white/60'} />
              <span className="hidden font-medium truncate md:inline">{label}</span>
              {badge && (
                <span className="absolute right-1 top-1 md:static md:ml-auto bg-amber-500 text-black text-[10px] font-bold
                                  w-5 h-5 rounded-full flex items-center justify-center">
                  {badge > 9 ? '9+' : badge}
                </span>
              )}
              {active && (
                <motion.div
                  layoutId="activeIndicator"
                  className="absolute right-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-jarvis-blue rounded-full"
                />
              )}
            </motion.button>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="px-2 md:px-4 py-4 border-t border-white/[0.06]">
        <div className="flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-white/[0.035] border border-white/[0.06] md:justify-start">
          <div className={`status-dot ${wsConnected ? 'online' : 'offline'}`} />
          <span className="hidden text-xs text-white/40 md:inline">
            {wsConnected ? 'Live telemetry' : 'Preview mode'}
          </span>
          <Activity size={12} className="ml-auto hidden text-white/20 md:block" />
        </div>
      </div>
    </aside>
  )
}
