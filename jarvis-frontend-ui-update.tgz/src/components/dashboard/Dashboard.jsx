import React, { useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Activity,
  Brain,
  CheckCircle2,
  CheckSquare,
  Clock,
  Globe2,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Users,
  Zap,
} from 'lucide-react'
import { getHealth, getPendingCount, getSystemStatus } from '../../services/api'
import useJarvisStore from '../../store/useJarvisStore'

const ZONES = [
  { city: 'London', tz: 'Europe/London', market: 'HQ' },
  { city: 'Dubai', tz: 'Asia/Dubai', market: 'Gulf' },
  { city: 'Hyderabad', tz: 'Asia/Kolkata', market: 'Build' },
  { city: 'New York', tz: 'America/New_York', market: 'US' },
]

const SIGNALS = [
  { label: 'Backend API', key: 'api' },
  { label: 'Database', key: 'database' },
  { label: 'Scheduler', key: 'scheduler' },
  { label: 'Team Registry', key: 'team_registry' },
]

function statusTone(ok) {
  return ok
    ? 'border-emerald-400/20 bg-emerald-400/10 text-emerald-300'
    : 'border-amber-400/20 bg-amber-400/10 text-amber-300'
}

function MetricCard({ icon: Icon, label, value, helper, tone = 'blue', delay = 0 }) {
  const tones = {
    blue: 'border-jarvis-blue/20 text-jarvis-blue bg-jarvis-blue/10',
    green: 'border-emerald-400/20 text-emerald-300 bg-emerald-400/10',
    amber: 'border-amber-400/20 text-amber-300 bg-amber-400/10',
    violet: 'border-violet-400/20 text-violet-300 bg-violet-400/10',
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.28 }}
      className="glass-hover p-4 rounded-lg"
    >
      <div className="flex items-start justify-between gap-3">
        <div className={`h-9 w-9 rounded-lg border flex items-center justify-center ${tones[tone]}`}>
          <Icon size={17} />
        </div>
        <span className="text-[10px] uppercase tracking-wider text-white/25 font-mono">{helper}</span>
      </div>
      <p className="mt-4 text-2xl font-semibold tracking-tight text-white">{value}</p>
      <p className="mt-1 text-xs text-white/40">{label}</p>
    </motion.div>
  )
}

function ReadinessSignal({ label, ok, detail }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border border-white/[0.06] bg-white/[0.025] px-3 py-2.5">
      <div className="flex items-center gap-2">
        <span className={`h-2 w-2 rounded-full ${ok ? 'bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.7)]' : 'bg-amber-400'}`} />
        <span className="text-sm text-white/70">{label}</span>
      </div>
      <span className={`rounded-full border px-2 py-0.5 text-[10px] font-medium uppercase ${statusTone(ok)}`}>
        {detail}
      </span>
    </div>
  )
}

export default function Dashboard() {
  const { setPendingApprovals, setProviders } = useJarvisStore()
  const [health, setHealth] = useState(null)
  const [status, setStatus] = useState(null)
  const [pending, setPending] = useState(0)
  const [times, setTimes] = useState({})
  const [loadError, setLoadError] = useState('')

  useEffect(() => {
    let mounted = true

    async function fetchData() {
      try {
        const [h, s, p] = await Promise.all([getHealth(), getSystemStatus(), getPendingCount()])
        if (!mounted) return
        setHealth(h)
        setStatus(s)
        setPending(p?.pending || 0)
        setPendingApprovals(p?.pending || 0)
        setProviders(h?.ai_providers || {})
        setLoadError('')
      } catch (error) {
        if (mounted) setLoadError('Live telemetry is unavailable. The UI is running in command preview mode.')
      }
    }

    function updateTimes() {
      const now = new Date()
      setTimes(Object.fromEntries(
        ZONES.map(({ city, tz }) => [
          city,
          now.toLocaleTimeString('en-GB', { timeZone: tz, hour: '2-digit', minute: '2-digit' }),
        ]),
      ))
    }

    fetchData()
    updateTimes()
    const dataTimer = setInterval(fetchData, 30000)
    const clockTimer = setInterval(updateTimes, 10000)

    return () => {
      mounted = false
      clearInterval(dataTimer)
      clearInterval(clockTimer)
    }
  }, [setPendingApprovals, setProviders])

  const aiAvailable = health?.ai_providers?.available ?? status?.ai_providers?.available ?? 0
  const aiTotal = health?.ai_providers?.total ?? status?.ai_providers?.total ?? 11
  const activeProviders = health?.ai_providers?.active || status?.ai_providers?.active || []

  const readiness = useMemo(() => {
    const checks = status?.checks || {}
    return SIGNALS.map((signal) => {
      if (signal.key === 'api') {
        return { ...signal, ok: health?.status === 'ok', detail: health?.status === 'ok' ? 'online' : 'check' }
      }
      const check = checks[signal.key]
      return { ...signal, ok: check?.status === 'ok' || check?.running === true, detail: check?.status || (check?.running ? 'ok' : 'pending') }
    })
  }, [health, status])

  return (
    <div className="h-full overflow-y-auto p-6 no-scrollbar">
      <div className="mx-auto flex max-w-7xl flex-col gap-5">
        <motion.section
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-lg border border-white/[0.08] bg-white/[0.045] px-6 py-5 shadow-2xl shadow-black/20"
        >
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-jarvis-blue/60 to-transparent" />
          <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
            <div className="max-w-2xl">
              <div className="mb-3 flex items-center gap-2">
                <span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-emerald-300">
                  Production MVP
                </span>
                <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[11px] font-mono text-white/45">
                  JARVIS v{health?.version || '9.0.0'}
                </span>
              </div>
              <h1 className="text-3xl font-semibold tracking-tight text-white md:text-4xl">
                Aliyar Solutions Command Center
              </h1>
              <p className="mt-2 max-w-xl text-sm leading-6 text-white/55">
                A premium operations cockpit for AI providers, approvals, client work, team readiness, and deployment health.
              </p>
              {loadError && (
                <p className="mt-3 rounded-lg border border-amber-400/20 bg-amber-400/10 px-3 py-2 text-xs text-amber-200">
                  {loadError}
                </p>
              )}
            </div>

            <div className="grid min-w-[280px] grid-cols-2 gap-3">
              <div className="rounded-lg border border-white/[0.07] bg-black/20 p-4">
                <p className="text-[10px] uppercase tracking-wider text-white/35">System State</p>
                <div className="mt-3 flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-full bg-emerald-400 shadow-[0_0_14px_rgba(52,211,153,0.8)]" />
                  <span className="text-sm font-semibold text-emerald-300">Operational</span>
                </div>
              </div>
              <div className="rounded-lg border border-white/[0.07] bg-black/20 p-4">
                <p className="text-[10px] uppercase tracking-wider text-white/35">AI Network</p>
                <p className="mt-2 text-2xl font-semibold text-jarvis-blue">{aiAvailable}/{aiTotal}</p>
              </div>
            </div>
          </div>
        </motion.section>

        <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
          <MetricCard icon={Brain} label="AI providers available" value={`${aiAvailable}/${aiTotal}`} helper="providers" tone="blue" delay={0.03} />
          <MetricCard icon={CheckSquare} label="Human approvals waiting" value={pending} helper="queue" tone="amber" delay={0.06} />
          <MetricCard icon={Users} label="Team registry members" value={status?.checks?.team_registry?.members || 9} helper="team" tone="violet" delay={0.09} />
          <MetricCard icon={TrendingUp} label="Production readiness score" value={health?.status === 'ok' ? '92%' : '68%'} helper="mvp" tone="green" delay={0.12} />
        </div>

        <div className="grid gap-5 xl:grid-cols-[1.15fr_0.85fr]">
          <motion.section
            initial={{ opacity: 0, x: -12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.15 }}
            className="glass p-5 rounded-lg"
          >
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck size={16} className="text-jarvis-blue" />
                <h2 className="text-sm font-semibold text-white/80">Production Readiness</h2>
              </div>
              <span className="text-[10px] uppercase tracking-wider text-white/30">Live checks</span>
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              {readiness.map((signal) => (
                <ReadinessSignal key={signal.key} label={signal.label} ok={signal.ok} detail={signal.detail} />
              ))}
            </div>
            <div className="mt-4 grid gap-3 md:grid-cols-3">
              {[
                ['Docker stack', 'Running'],
                ['Nginx edge', 'HTTP 200'],
                ['Deploy path', 'EC2 ready'],
              ].map(([label, value]) => (
                <div key={label} className="rounded-lg border border-white/[0.06] bg-black/20 p-3">
                  <p className="text-[10px] uppercase tracking-wider text-white/30">{label}</p>
                  <p className="mt-1 text-sm font-medium text-white/75">{value}</p>
                </div>
              ))}
            </div>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, x: 12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="glass p-5 rounded-lg"
          >
            <div className="mb-4 flex items-center gap-2">
              <Globe2 size={16} className="text-jarvis-blue" />
              <h2 className="text-sm font-semibold text-white/80">Market Clock</h2>
            </div>
            <div className="space-y-2">
              {ZONES.map(({ city, market }) => (
                <div key={city} className="flex items-center justify-between rounded-lg border border-white/[0.06] bg-white/[0.025] px-3 py-2.5">
                  <div>
                    <p className="text-sm text-white/75">{city}</p>
                    <p className="text-[10px] uppercase tracking-wider text-white/30">{market}</p>
                  </div>
                  <span className="font-mono text-sm text-jarvis-blue">{times[city] || '--:--'}</span>
                </div>
              ))}
            </div>
          </motion.section>
        </div>

        <div className="grid gap-5 xl:grid-cols-3">
          <motion.section
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.24 }}
            className="glass p-5 rounded-lg xl:col-span-2"
          >
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles size={16} className="text-jarvis-blue" />
                <h2 className="text-sm font-semibold text-white/80">Active Intelligence Providers</h2>
              </div>
              <span className="text-[10px] uppercase tracking-wider text-white/30">failover ready</span>
            </div>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {(activeProviders.length ? activeProviders : ['openai', 'google']).map((name) => (
                <div key={name} className="flex items-center justify-between rounded-lg border border-white/[0.06] bg-white/[0.025] px-3 py-2.5">
                  <span className="text-xs font-mono text-white/65">{name}</span>
                  <CheckCircle2 size={14} className="text-emerald-300" />
                </div>
              ))}
            </div>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.28 }}
            className="glass p-5 rounded-lg"
          >
            <div className="mb-4 flex items-center gap-2">
              <Zap size={16} className="text-jarvis-blue" />
              <h2 className="text-sm font-semibold text-white/80">MVP Launch Path</h2>
            </div>
            <div className="space-y-3">
              {[
                ['Deploy core stack', true],
                ['Verify health endpoints', true],
                ['Attach domain and SSL', false],
                ['Enable CI/CD secrets', false],
              ].map(([label, done]) => (
                <div key={label} className="flex items-center gap-3">
                  <span className={`flex h-6 w-6 items-center justify-center rounded-full border ${done ? 'border-emerald-400/25 bg-emerald-400/10 text-emerald-300' : 'border-white/10 bg-white/[0.03] text-white/30'}`}>
                    {done ? <CheckCircle2 size={13} /> : <Clock size={13} />}
                  </span>
                  <span className={`text-sm ${done ? 'text-white/75' : 'text-white/40'}`}>{label}</span>
                </div>
              ))}
            </div>
          </motion.section>
        </div>

        <motion.section
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.32 }}
          className="rounded-lg border border-jarvis-blue/15 bg-jarvis-blue/[0.055] p-4"
        >
          <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-2">
              <Activity size={16} className="text-jarvis-blue" />
              <p className="text-sm font-medium text-white/80">Next premium layer</p>
            </div>
            <p className="text-xs text-white/50">
              Domain + SSL, GitHub Actions secrets, uptime monitoring, and Grafana will take this from live MVP to production-grade.
            </p>
          </div>
        </motion.section>
      </div>
    </div>
  )
}
