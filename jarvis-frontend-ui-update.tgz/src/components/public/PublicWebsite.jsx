import React, { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  ArrowRight,
  BarChart3,
  BriefcaseBusiness,
  CheckCircle2,
  Cloud,
  Code2,
  Film,
  Layers3,
  LockKeyhole,
  Mail,
  Network,
  Phone,
  ShieldCheck,
  Sparkles,
  Users,
  Workflow,
} from 'lucide-react'

const GROUPS = [
  { id: 'workflow', title: 'Intelligent Workflow Systems', icon: Workflow },
  { id: 'cloud', title: 'Cloud & DevOps', icon: Cloud },
  { id: 'revenue', title: 'Sales & Revenue Systems', icon: BriefcaseBusiness },
  { id: 'security', title: 'Cybersecurity', icon: LockKeyhole },
  { id: 'content', title: 'Content & Media', icon: Film },
  { id: 'products', title: 'Digital Products', icon: Code2 },
  { id: 'intelligence', title: 'Business Intelligence', icon: BarChart3 },
]

const SERVICES = [
  { group: 'revenue', title: 'Intelligent Lead Generation Systems', desc: 'Our specialists design qualified prospect pipelines, enrich contact data, and deliver clear opportunity reports for growth teams.' },
  { group: 'revenue', title: 'Precision Outreach Systems', desc: 'Our expert team builds personalized email and LinkedIn programs with disciplined testing, inbox readiness, and reply management.' },
  { group: 'revenue', title: 'Sales Operating Systems', desc: 'We deliver structured revenue infrastructure for targeting, proposals, follow-up discipline, and executive pipeline visibility.' },
  { group: 'revenue', title: 'CRM Revenue Operations', desc: 'Our team configures CRM workflows, lifecycle stages, scoring rules, clean data, and management dashboards for repeatable execution.' },
  { group: 'workflow', title: 'Appointment Booking Systems', desc: 'Our specialists implement polished scheduling flows with qualification, calendar coordination, reminders, and CRM handoff.' },
  { group: 'workflow', title: 'Voice Receptionist Systems', desc: 'We deploy professional phone reception experiences for intake, routing, FAQs, appointments, and escalation to your staff.' },
  { group: 'workflow', title: 'Smart Business Operations', desc: 'Our team maps your processes, removes repetitive handoffs, and implements intelligent systems that streamline daily operations.' },
  { group: 'workflow', title: 'Executive Operations Systems', desc: 'We deliver reporting, decision support, KPI monitoring, and operational briefing systems for leadership teams.' },
  { group: 'cloud', title: 'DevOps Infrastructure Services', desc: 'Our engineers standardize environments, delivery pipelines, monitoring, and runbooks for reliable software operations.' },
  { group: 'cloud', title: 'AWS Cloud Architecture', desc: 'We design and implement production-grade AWS platforms with networking, compute, databases, secrets, monitoring, and resilience planning.' },
  { group: 'cloud', title: 'Docker Deployments', desc: 'Our engineers containerize applications with optimized images, compose environments, registry setup, and deployment documentation.' },
  { group: 'cloud', title: 'CI/CD Delivery Systems', desc: 'We implement reliable build, test, release, and rollback pipelines so engineering teams ship with confidence.' },
  { group: 'cloud', title: 'Jenkins Infrastructure', desc: 'Our specialists set up secure Jenkins platforms with agent architecture, shared libraries, pipelines, and source control integrations.' },
  { group: 'cloud', title: 'Terraform Infrastructure Systems', desc: 'We build reusable infrastructure modules, remote state, workspace strategy, and disciplined cloud provisioning workflows.' },
  { group: 'cloud', title: 'Ansible Configuration Systems', desc: 'Our engineers create playbooks, roles, inventories, and secure configuration management for consistent server environments.' },
  { group: 'cloud', title: 'Kubernetes Infrastructure', desc: 'We design production clusters with namespaces, RBAC, Helm, autoscaling, ingress, storage, observability, and GitOps practices.' },
  { group: 'cloud', title: 'Monitoring & Logging Systems', desc: 'Our team deploys metrics, logs, dashboards, traces, alert rules, and runbooks for high-confidence operations.' },
  { group: 'cloud', title: 'SaaS Deployment Services', desc: 'We deliver SaaS launch infrastructure with tenancy planning, databases, SSL, CDN, readiness checks, and release discipline.' },
  { group: 'security', title: 'Cybersecurity Operations', desc: 'Our security consultants harden infrastructure, review IAM, improve access controls, and prepare incident response playbooks.' },
  { group: 'security', title: 'Vulnerability Assessment', desc: 'We identify application, infrastructure, and API risks, then provide prioritized remediation plans and executive summaries.' },
  { group: 'content', title: 'Content Production Systems', desc: 'Our creative specialists design scalable editorial workflows, brand voice guides, publishing calendars, and performance reporting.' },
  { group: 'content', title: 'YouTube Production Pipelines', desc: 'We build channel operations for research, scripting, voiceover coordination, thumbnails, publishing, and performance review.' },
  { group: 'content', title: 'Social Media Management', desc: 'Our team handles content planning, scheduling, creative direction, engagement review, and multi-platform growth reporting.' },
  { group: 'content', title: 'Graphic Design Systems', desc: 'We create brand assets, social templates, marketing collateral, presentations, infographics, and design libraries.' },
  { group: 'content', title: 'Video Editing Pipelines', desc: 'Our media specialists design editing, captioning, color, templates, format conversion, and multi-channel export workflows.' },
  { group: 'products', title: 'Website Development', desc: 'We deliver premium, conversion-focused websites with modern frontend engineering, mobile-first design, CMS setup, and performance tuning.' },
  { group: 'products', title: 'Client Portal Systems', desc: 'Our engineers build branded portals for project tracking, documents, communication, invoices, dashboards, and client reporting.' },
  { group: 'products', title: 'Operational Dashboards', desc: 'We build real-time executive dashboards for KPIs, infrastructure health, revenue visibility, and custom reporting.' },
  { group: 'intelligence', title: 'Market Research Operations', desc: 'Our analysts deliver competitor reviews, opportunity maps, technology landscape reports, and strategic recommendations.' },
  { group: 'intelligence', title: 'Business Intelligence Analytics', desc: 'We design data pipelines, warehouses, dashboards, forecasts, executive reports, and decision-ready analytics systems.' },
]

const TEAM = [
  ['Darren Mitchell', 'Client Acquisition Specialist'],
  ['David Carter', 'Solutions Architect'],
  ['Sophia Reynolds', 'Workflow Consultant'],
  ['Nathan Scott', 'Deployment Engineer'],
  ['Emma Collins', 'Business Optimisation Specialist'],
  ['Daniel Brooks', 'Security Consultant'],
  ['Michael Hayes', 'Infrastructure Strategist'],
  ['Lucas Reed', 'Process Integration Specialist'],
  ['Olivia Bennett', 'Account Coordinator'],
]

const TRENDING = [
  'Intelligent System Development',
  'Custom Chat Interfaces',
  'Smart App & Website Builder',
  'Smart Business Operations',
  'Voice Receptionist Systems',
  'Intelligent Lead Generation',
]

const BUDGETS = ['Under $3K', '$3K-$8K', '$8K-$25K', 'Enterprise']

function Section({ id, eyebrow, title, children }) {
  return (
    <section id={id} className="mx-auto w-full max-w-7xl px-5 py-16 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-80px' }}
        transition={{ duration: 0.45 }}
      >
        <p className="text-xs font-semibold uppercase tracking-[0.28em] text-[#8fb6ff]">{eyebrow}</p>
        <h2 className="mt-3 max-w-3xl text-3xl font-semibold tracking-tight text-white sm:text-4xl">{title}</h2>
        {children}
      </motion.div>
    </section>
  )
}

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-medium text-white/72">{label}</span>
      {children}
    </label>
  )
}

const inputClass = 'w-full rounded-lg border border-white/10 bg-white/[0.045] px-4 py-3 text-sm text-white outline-none transition placeholder:text-white/28 focus:border-[#2D6FE8]/70 focus:bg-white/[0.07]'

export default function PublicWebsite() {
  const [form, setForm] = useState({
    fullName: '',
    company: '',
    email: '',
    phone: '',
    service: SERVICES[0].title,
    budget: BUDGETS[1],
    consultation: 'Yes',
    emailOk: 'Yes',
    description: '',
  })
  const [status, setStatus] = useState('')
  const servicesByGroup = useMemo(() => GROUPS.map((group) => ({
    ...group,
    services: SERVICES.filter((service) => service.group === group.id),
  })), [])

  const update = (key, value) => setForm((current) => ({ ...current, [key]: value }))

  async function submitRequest(event) {
    event.preventDefault()
    setStatus('Submitting request...')
    try {
      const response = await fetch('/api/v1/crm/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          full_name: form.fullName,
          company_name: form.company,
          email: form.email,
          phone: form.phone,
          service_required: form.service,
          project_budget: form.budget,
          consultation_call: form.consultation === 'Yes',
          email_contact_ok: form.emailOk === 'Yes',
          project_description: form.description,
          source: 'aliyarsolutions.com',
        }),
      })
      if (!response.ok) throw new Error('Request failed')
      setStatus('Request submitted. Our team will reach out shortly.')
      setForm((current) => ({ ...current, fullName: '', company: '', email: '', phone: '', description: '' }))
    } catch {
      setStatus('We could not submit the request yet. Please email hello@aliyarsolutions.com.')
    }
  }

  return (
    <div className="min-h-screen bg-[#0A0E1A] text-white">
      <div className="fixed inset-0 pointer-events-none bg-[radial-gradient(circle_at_20%_10%,rgba(45,111,232,0.22),transparent_34%),radial-gradient(circle_at_80%_0%,rgba(255,255,255,0.08),transparent_28%)]" />

      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#0A0E1A]/86 backdrop-blur-xl">
        <div className="bg-[#2D6FE8] px-4 py-2 text-center text-sm font-semibold text-white">
          🔥 Limited offer — 30% OFF all services until 21st May 2026
        </div>
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 sm:px-6 lg:px-8">
          <a href="#top" className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#2D6FE8]/40 bg-[#2D6FE8]/16">
              <Layers3 size={18} className="text-[#8fb6ff]" />
            </span>
            <span>
              <span className="block text-sm font-semibold tracking-[0.18em]">ALIYAR</span>
              <span className="block text-xs uppercase tracking-[0.28em] text-white/42">Solutions</span>
            </span>
          </a>
          <div className="hidden items-center gap-7 text-sm text-white/62 md:flex">
            <a href="#services" className="hover:text-white">Services</a>
            <a href="#why" className="hover:text-white">About</a>
            <a href="#contact" className="hover:text-white">Contact</a>
          </div>
          <a href="#contact" className="rounded-lg bg-white px-4 py-2 text-sm font-semibold text-[#0A0E1A] transition hover:bg-[#dce8ff]">
            Start Project
          </a>
        </nav>
      </header>

      <main id="top" className="relative">
        <section className="mx-auto grid min-h-[calc(100vh-110px)] max-w-7xl items-center gap-10 px-5 py-20 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:px-8">
          <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.55 }}>
            <p className="mb-5 inline-flex rounded-full border border-white/10 bg-white/[0.06] px-4 py-2 text-xs font-medium uppercase tracking-[0.24em] text-[#b9d0ff]">
              Enterprise Technology Company
            </p>
            <h1 className="max-w-4xl text-5xl font-semibold leading-[0.95] tracking-tight text-white sm:text-6xl lg:text-7xl">
              Enterprise Technology. Intelligent Operations.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-white/64">
              Aliyar Solutions delivers expert-led infrastructure, cloud architecture, and business operations systems to companies worldwide.
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <a href="#contact" className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#2D6FE8] px-6 py-3 text-sm font-semibold text-white shadow-2xl shadow-[#2D6FE8]/25 transition hover:bg-[#3f80f4]">
                Get Started <ArrowRight size={16} />
              </a>
              <a href="#services" className="inline-flex items-center justify-center rounded-lg border border-white/12 bg-white/[0.05] px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/[0.09]">
                View Services
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.65, delay: 0.12 }}
            className="rounded-[2rem] border border-white/10 bg-white/[0.045] p-4 shadow-2xl shadow-black/40 backdrop-blur-xl"
          >
            <div className="rounded-[1.5rem] border border-white/10 bg-[#080c16] p-6">
              <div className="mb-8 flex items-center justify-between">
                <span className="text-xs uppercase tracking-[0.22em] text-white/40">Delivery Board</span>
                <span className="rounded-full bg-emerald-400/12 px-3 py-1 text-xs font-semibold text-emerald-300">Active</span>
              </div>
              <div className="space-y-4">
                {['Architecture review', 'Cloud readiness', 'Operations design', 'Launch support'].map((item, index) => (
                  <div key={item} className="flex items-center gap-4 rounded-xl border border-white/8 bg-white/[0.04] p-4">
                    <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#2D6FE8]/16 text-sm font-semibold text-[#8fb6ff]">0{index + 1}</span>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-white">{item}</p>
                      <div className="mt-2 h-1.5 rounded-full bg-white/8">
                        <div className="h-full rounded-full bg-[#2D6FE8]" style={{ width: `${72 + index * 6}%` }} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </section>

        <Section id="services" eyebrow="Services" title="Thirty specialist divisions, organized for enterprise delivery.">
          <div className="mt-10 space-y-10">
            {servicesByGroup.map(({ id, title, icon: Icon, services }) => (
              <div key={id} className="rounded-2xl border border-white/10 bg-white/[0.035] p-4 backdrop-blur-xl sm:p-5">
                <div className="mb-5 flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#2D6FE8]/15 text-[#8fb6ff]">
                    <Icon size={18} />
                  </span>
                  <h3 className="text-xl font-semibold text-white">{title}</h3>
                </div>
                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                  {services.map((service, index) => (
                    <motion.article
                      key={service.title}
                      initial={{ opacity: 0, y: 12 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: Math.min(index * 0.03, 0.18) }}
                      className="group rounded-xl border border-white/10 bg-[#0A0E1A]/70 p-5 transition hover:-translate-y-1 hover:border-[#2D6FE8]/45 hover:bg-white/[0.055]"
                    >
                      <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-lg bg-white/[0.06] text-[#8fb6ff]">
                        <Icon size={19} />
                      </div>
                      <h4 className="text-base font-semibold text-white">{service.title}</h4>
                      <p className="mt-3 min-h-[72px] text-sm leading-6 text-white/54">{service.desc}</p>
                      <a href="#contact" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-[#8fb6ff]">
                        Learn More <ArrowRight size={14} className="transition group-hover:translate-x-1" />
                      </a>
                    </motion.article>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Section>

        <Section id="why" eyebrow="Why Aliyar Solutions" title="A senior delivery partner for serious technical work.">
          <div className="mt-9 grid gap-4 md:grid-cols-2">
            {[
              'Enterprise-grade delivery',
              'Expert-led operations',
              'Global team, 24/7 operations',
              'Fast turnaround, premium quality',
            ].map((item) => (
              <div key={item} className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.04] p-5">
                <CheckCircle2 size={20} className="text-[#8fb6ff]" />
                <p className="font-medium text-white/86">{item}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {['30+ Services', '24/7 Operations', 'Global Clients', 'Enterprise Grade'].map((stat) => (
              <div key={stat} className="rounded-xl border border-[#2D6FE8]/20 bg-[#2D6FE8]/10 p-6 text-center">
                <p className="text-2xl font-semibold text-white">{stat}</p>
              </div>
            ))}
          </div>
        </Section>

        <Section id="process" eyebrow="How It Works" title="A clear path from consultation to scale.">
          <div className="mt-10 grid gap-4 md:grid-cols-4">
            {[
              ['Step 1', 'Book a consultation'],
              ['Step 2', 'Our team designs your solution'],
              ['Step 3', 'We build and deploy'],
              ['Step 4', 'You scale'],
            ].map(([step, text]) => (
              <div key={step} className="rounded-xl border border-white/10 bg-white/[0.04] p-5">
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#8fb6ff]">{step}</p>
                <p className="mt-4 text-lg font-semibold text-white">{text}</p>
              </div>
            ))}
          </div>
        </Section>

        <Section id="trending" eyebrow="Trending Services" title="High-demand systems our specialists are delivering now.">
          <div className="mt-8 flex flex-wrap gap-3">
            {TRENDING.map((item) => (
              <span key={item} className="inline-flex items-center gap-2 rounded-full border border-[#2D6FE8]/30 bg-[#2D6FE8]/12 px-4 py-2 text-sm font-semibold text-[#c7d9ff]">
                <Sparkles size={14} /> {item}
              </span>
            ))}
          </div>
        </Section>

        <Section id="contact" eyebrow="Start Your Project" title="Tell us what you want to build. Our team will review it.">
          <form onSubmit={submitRequest} className="mt-9 rounded-2xl border border-white/10 bg-white/[0.045] p-5 backdrop-blur-xl sm:p-8">
            <div className="grid gap-5 md:grid-cols-2">
              <Field label="Full Name">
                <input required value={form.fullName} onChange={(e) => update('fullName', e.target.value)} className={inputClass} />
              </Field>
              <Field label="Company Name">
                <input required value={form.company} onChange={(e) => update('company', e.target.value)} className={inputClass} />
              </Field>
              <Field label="Email Address">
                <input required type="email" value={form.email} onChange={(e) => update('email', e.target.value)} className={inputClass} />
              </Field>
              <Field label="Phone Number (optional)">
                <input value={form.phone} onChange={(e) => update('phone', e.target.value)} className={inputClass} />
              </Field>
              <Field label="Service Required">
                <select value={form.service} onChange={(e) => update('service', e.target.value)} className={inputClass}>
                  {SERVICES.map((service) => <option key={service.title} className="bg-[#0A0E1A]">{service.title}</option>)}
                </select>
              </Field>
              <Field label="Project Budget">
                <select value={form.budget} onChange={(e) => update('budget', e.target.value)} className={inputClass}>
                  {BUDGETS.map((budget) => <option key={budget} className="bg-[#0A0E1A]">{budget}</option>)}
                </select>
              </Field>
            </div>

            <div className="mt-5 grid gap-4 md:grid-cols-2">
              {[
                ['consultation', 'Do you need a consultation call?'],
                ['emailOk', 'Are you comfortable being contacted via email?'],
              ].map(([key, label]) => (
                <div key={key} className="rounded-xl border border-white/10 bg-white/[0.035] p-4">
                  <p className="text-sm font-medium text-white/72">{label}</p>
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    {['Yes', 'No'].map((option) => (
                      <button
                        type="button"
                        key={option}
                        onClick={() => update(key, option)}
                        className={`rounded-lg border px-4 py-2 text-sm font-semibold transition ${form[key] === option ? 'border-[#2D6FE8] bg-[#2D6FE8] text-white' : 'border-white/10 bg-white/[0.04] text-white/58'}`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-5">
              <Field label="Project Description">
                <textarea required rows={6} value={form.description} onChange={(e) => update('description', e.target.value)} className={inputClass} />
              </Field>
            </div>

            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
              <button type="submit" className="inline-flex items-center justify-center rounded-lg bg-[#2D6FE8] px-6 py-3 text-sm font-semibold text-white transition hover:bg-[#3f80f4]">
                Submit Request — Our Team Will Reach Out
              </button>
              {status && <p className="text-sm text-white/58">{status}</p>}
            </div>
          </form>
        </Section>

        <Section id="team" eyebrow="Team" title="Dedicated professionals across strategy, engineering, security, and client delivery.">
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {TEAM.map(([name, role], index) => (
              <motion.div
                key={name}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.03 }}
                className="rounded-xl border border-white/10 bg-white/[0.04] p-5"
              >
                <div className="flex items-center gap-4">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full border border-[#2D6FE8]/35 bg-[#2D6FE8]/14 text-lg font-semibold text-[#c7d9ff]">
                    {name.split(' ').map((part) => part[0]).join('')}
                  </div>
                  <div>
                    <h3 className="font-semibold text-white">{name}</h3>
                    <p className="text-sm text-white/52">{role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </Section>
      </main>

      <footer className="relative border-t border-white/10 px-5 py-10 sm:px-6 lg:px-8">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-lg font-semibold text-white">Aliyar Solutions</p>
            <a href="mailto:hello@aliyarsolutions.com" className="mt-2 inline-flex items-center gap-2 text-sm text-white/55 hover:text-white">
              <Mail size={14} /> hello@aliyarsolutions.com
            </a>
            <p className="mt-2 text-xs uppercase tracking-[0.22em] text-white/32">Enterprise Technology Company</p>
          </div>
          <div className="flex gap-5 text-sm text-white/55">
            <a href="#services" className="hover:text-white">Services</a>
            <a href="#why" className="hover:text-white">About</a>
            <a href="#contact" className="hover:text-white">Contact</a>
          </div>
          <p className="text-sm text-white/42">© 2026 Aliyar Solutions. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
